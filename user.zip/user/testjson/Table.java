package com.jrr.user.testjson;

import java.util.List;

/**
 * Created by user on 2018/9/9.
 */

public class Table {

	private int code;
	private int tableCount;
	private List<TableContent> mTableContent;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public int getTableCount() {
		return tableCount;
	}

	public void setTableCount(int tableCount) {
		this.tableCount = tableCount;
	}

	public List<TableContent> getmTableContent() {
		return mTableContent;
	}

	public void setmTableContent(List<TableContent> mTableContent) {
		this.mTableContent = mTableContent;
	}
	
	
}
