package com.jrr.user.testjson2;

import java.util.List;

/**
 * Created by user on 2018/9/9.
 */

public class TableContent {


    private int id;

    public List<Block> getBody() {
        return body;
    }

    public void setBody(List<Block> body) {
        this.body = body;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private List<Block> body;


}
