package com.jrr.user.testjson2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.google.gson.Gson;

/**
 * Created by user on 2018/9/9.
 */

public class Test {

	String[] s = {
			"1 1,1 1,1 1,1 1 (11) 2 2,2 2,2 2,2 2 (12) 3 3,3 3,3 3,3 3 (13) 1 1 1 1 1 1 1 1 (11) 2 2 2 2 2 2 2 2 (12) 3 3 3 3 3 3 3 3 (13)",
			"a,b,c,a,b,c", "1 1 1 1;1 1 1 1;1 1 2 2;1 1 1 1;1 1 1 1;1 1 2 2" };

	public Table covertToTable() {
		String[] tables = s[0].split("\\(13\\)");
		String[] values = s[1].split(",");
		String[] pos = s[2].split(";");
		String[][] rowColoumns = new String[pos.length][4];
		for (int index = 0; index < pos.length; index++) {
			String[] item = pos[index].split(" ");
			rowColoumns[index][0] = item[0];
			rowColoumns[index][1] = item[1];
			rowColoumns[index][2] = item[2];
			rowColoumns[index][3] = item[3];
		}

		Table table = new Table();
		List<TableContent> tableContents = new ArrayList<>();
		table.setCode(0);

		int tableCount = tables.length;
		table.setTableCount(tableCount);
		int blockCount = 0;
		for (int i = 0; i < tableCount; i++) {
			String[] blocks = tables[i].split("\\(11\\)|\\(12\\)");
			List<Block> bodies = new ArrayList<>();
			for (String block : blocks) {
				blockCount++;
				Block mBlock = new Block();
				mBlock.setPosition(Arrays.asList(block.trim().split(" |,")));
				mBlock.setValues(values[blockCount - 1]);
				mBlock.setmStartRow(rowColoumns[blockCount - 1][0]);
				mBlock.setmEndRow(rowColoumns[blockCount - 1][1]);
				mBlock.setmStartColumn(rowColoumns[blockCount - 1][2]);
				mBlock.setmEndColumn(rowColoumns[blockCount - 1][3]);
				bodies.add(mBlock);
			}
			TableContent tableContent = new TableContent();
			tableContent.setId(i);
			tableContent.setBody(bodies);
			tableContents.add(tableContent);
		}
		table.setmTableContent(tableContents);
		
		return table;
	}
	
	public static void main(String[] args) {
		Table table = new Test().covertToTable();
		Gson gson = new Gson();
		String json = gson.toJson(table);
		System.out.println(json);
		System.out.println(gson.fromJson(json, Table.class));
	}

}
