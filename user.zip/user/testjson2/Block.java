package com.jrr.user.testjson2;

import java.util.List;

/**
 * Created by user on 2018/9/9.
 */

public class Block {

	public String mStartRow;
	public String mEndRow;
	public String mStartColumn;
	public String mEndColumn;
	public String values;
	public List<String> position;

	public String getmStartRow() {
		return mStartRow;
	}

	public void setmStartRow(String mStartRow) {
		this.mStartRow = mStartRow;
	}

	public String getmEndRow() {
		return mEndRow;
	}

	public void setmEndRow(String mEndRow) {
		this.mEndRow = mEndRow;
	}

	public String getmStartColumn() {
		return mStartColumn;
	}

	public void setmStartColumn(String mStartColumn) {
		this.mStartColumn = mStartColumn;
	}

	public String getmEndColumn() {
		return mEndColumn;
	}

	public void setmEndColumn(String mEndColumn) {
		this.mEndColumn = mEndColumn;
	}

	public String getValues() {
		return values;
	}

	public void setValues(String values) {
		this.values = values;
	}

	public List<String> getPosition() {
		return position;
	}

	public void setPosition(List<String> position) {
		this.position = position;
	}
}
