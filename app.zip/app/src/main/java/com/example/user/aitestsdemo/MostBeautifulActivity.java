package com.example.user.aitestsdemo;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.DrawableRes;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import com.roamer.ui.view.SquareCenterImageView;


public class MostBeautifulActivity extends Activity implements View.OnClickListener, ImagesActivityGridViewAdapter.OnItemClickListener {
    public static final String SDCARD_PATH = Environment.getExternalStorageDirectory().toString();
    private GridView mGridView;
    private ImageView mostBeautifulPic;
    private Button selectBeautifulPic, canle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beautiful);
        mostBeautifulPic = (ImageView) findViewById(R.id.most_beautiful_pic);
        selectBeautifulPic = (Button) findViewById(R.id.bt_select);
        canle = (Button) findViewById(R.id.bt_cancle);


        mGridView = (GridView) findViewById(R.id.multi_photo_grid);
        int[] datas = new int[]{R.drawable.anim1, R.drawable.anim2, R.drawable.anim3,
                R.drawable.anim3, R.drawable.anim4, R.drawable.anim5};

        mGridView.setAdapter(new ImagesActivityGridViewAdapter(datas, MostBeautifulActivity.this, this));
        selectBeautifulPic.setOnClickListener(this);
        canle.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.bt_select:

                String path = getResourcesUri(R.drawable.anim1);
                Toast.makeText(MostBeautifulActivity.this, "选择最美图片path" + path, Toast.LENGTH_SHORT).show();

                break;
            case R.id.bt_cancle:

                Toast.makeText(MostBeautifulActivity.this, "清除选择的最美图片", Toast.LENGTH_SHORT).show();

                break;

        }


    }


    private String getResourcesUri(@DrawableRes int id) {
        Resources resources = getResources();
        String uriPath = ContentResolver.SCHEME_ANDROID_RESOURCE + "://" +
                resources.getResourcePackageName(id) + "/" +
                resources.getResourceTypeName(id) + "/" +
                resources.getResourceEntryName(id);
        return uriPath;
    }

    @Override
    public void onItemClick(SquareCenterImageView imageView, int[] datas, int position) {

        Intent intent = new Intent(MostBeautifulActivity.this, SpaceImageDetailActivity.class);
        intent.putExtra("images", datas);
        intent.putExtra("position", position);
        int[] location = new int[2];
        imageView.getLocationOnScreen(location);
        intent.putExtra("locationX", location[0]);
        intent.putExtra("locationY", location[1]);

        intent.putExtra("width", imageView.getWidth());
        intent.putExtra("height", imageView.getHeight());
        startActivity(intent);
        overridePendingTransition(0, 0);

    }


  /*  class ImagesInnerGridViewAdapter extends BaseAdapter {

        private int[] datas;


        public ImagesInnerGridViewAdapter(int[] datas) {
            this.datas = datas;
        }

        @Override
        public int getCount() {
            return datas.length;
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            final SquareCenterImageView imageView = new SquareCenterImageView(MostBeautifulActivity.this);
            imageView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            imageView.setScaleType(ScaleType.CENTER_CROP);

            int image_id = datas[position];
            imageView.setImageResource(image_id);//设置显示资源

            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MostBeautifulActivity.this, SpaceImageDetailActivity.class);
                    intent.putExtra("images", datas);
                    intent.putExtra("position", position);
                    int[] location = new int[2];
                    imageView.getLocationOnScreen(location);
                    intent.putExtra("locationX", location[0]);
                    intent.putExtra("locationY", location[1]);

                    intent.putExtra("width", imageView.getWidth());
                    intent.putExtra("height", imageView.getHeight());
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                }
            });
            return imageView;
        }
*/
//
//    }
}
