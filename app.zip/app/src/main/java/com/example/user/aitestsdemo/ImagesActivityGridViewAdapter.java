package com.example.user.aitestsdemo;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView.ScaleType;
import android.widget.Toast;

import com.roamer.ui.view.SquareCenterImageView;


public class ImagesActivityGridViewAdapter extends BaseAdapter {


    private int[] datas;
    OnItemClickListener onItemClickListener;
    Context context;


    public ImagesActivityGridViewAdapter(int[] datas, Context context, OnItemClickListener onItemClickListener) {
        this.datas = datas;
        this.context = context;
        this.onItemClickListener = onItemClickListener;
    }


    public interface OnItemClickListener {
        public void onItemClick(SquareCenterImageView imageView, int[] datas, int position);
    }

    @Override
    public int getCount() {
        return datas.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        final SquareCenterImageView imageView = new SquareCenterImageView(context);
        imageView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        imageView.setScaleType(ScaleType.CENTER_CROP);
        int image_id = datas[position];
        imageView.setImageResource(image_id);//设置显示资源


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(context, "图片呗点击了", Toast.LENGTH_SHORT).show();

                onItemClickListener.onItemClick(imageView, datas, position);


           /*         Intent intent = new Intent(context, SpaceImageDetailActivity.class);
                    intent.putExtra("images", datas);
                    intent.putExtra("position", position);
                    int[] location = new int[2];
                    imageView.getLocationOnScreen(location);
                    intent.putExtra("locationX", location[0]);
                    intent.putExtra("locationY", location[1]);

                    intent.putExtra("width", imageView.getWidth());
                    intent.putExtra("height", imageView.getHeight());
                    startActivity(intent);
                    overridePendingTransition(0, 0);*/
            }
        });
        return imageView;
    }


}
