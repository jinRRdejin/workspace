package com.example.user.aitestsdemo;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Created by user on 2018/7/29.
 */

public class MainActivity extends Activity implements View.OnClickListener{

    private Button mostBeautiful,faceRecognition,genderRecognition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout);

        mostBeautiful= (Button) findViewById(R.id.bt_most);
        faceRecognition= (Button) findViewById(R.id.bt_face);
        genderRecognition= (Button) findViewById(R.id.bt_gender);

        mostBeautiful.setOnClickListener(this);
        faceRecognition.setOnClickListener(this);
        genderRecognition.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.bt_most:
                Intent intent = new Intent(MainActivity.this,MostBeautifulActivity.class);
                startActivity(intent);
                break;
            case R.id.bt_face:
                break;
            case R.id.bt_gender:
                break;
            default:
                break;

        }


    }
}
