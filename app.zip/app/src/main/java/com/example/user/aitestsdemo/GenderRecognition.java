package com.example.user.aitestsdemo;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by user on 2018/7/29.
 */

public class GenderRecognition extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
