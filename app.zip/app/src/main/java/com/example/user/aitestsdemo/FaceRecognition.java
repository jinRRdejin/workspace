package com.example.user.aitestsdemo;

import android.app.Activity;
import android.os.Bundle;
import android.widget.GridView;

/**
 * Created by user on 2018/7/29.
 */

public class FaceRecognition extends Activity {
    private GridView mGridView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        mGridView = (GridView) findViewById(R.id.multi_photo_grid);
        int[] datas = new int[]{R.drawable.anim1, R.drawable.anim2, R.drawable.anim3,
                R.drawable.anim3, R.drawable.anim4, R.drawable.anim5};

    }


}
